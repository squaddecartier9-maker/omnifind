const { clerkClient } = require('@clerk/express');
const { query } = require('../db/client');

// Verify Clerk JWT and attach user to req
async function requireAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing authorization header' });
    }

    const token = authHeader.split(' ')[1];
    const payload = await clerkClient.verifyToken(token);
    const clerkId = payload.sub;

    const result = await query(
      'SELECT * FROM users WHERE clerk_id = $1',
      [clerkId]
    );

    if (!result.rows.length) {
      // Auto-create user on first request
      const clerkUser = await clerkClient.users.getUser(clerkId);
      const email = clerkUser.emailAddresses[0]?.emailAddress;
      const name = `${clerkUser.firstName || ''} ${clerkUser.lastName || ''}`.trim();

      const newUser = await query(
        `INSERT INTO users (clerk_id, email, name, avatar_url)
         VALUES ($1, $2, $3, $4)
         RETURNING *`,
        [clerkId, email, name, clerkUser.imageUrl]
      );
      req.user = newUser.rows[0];
    } else {
      req.user = result.rows[0];
    }

    next();
  } catch (err) {
    console.error('Auth error:', err.message);
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// Optional auth — attaches user if token present, continues either way
async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) return next();
    const token = authHeader.split(' ')[1];
    const payload = await clerkClient.verifyToken(token);
    const result = await query('SELECT * FROM users WHERE clerk_id = $1', [payload.sub]);
    if (result.rows.length) req.user = result.rows[0];
  } catch (_) {}
  next();
}

// Check user owns a store
async function requireStoreOwner(req, res, next) {
  const storeId = req.params.storeId || req.body.store_id;
  if (!storeId) return res.status(400).json({ error: 'Store ID required' });

  const result = await query(
    'SELECT * FROM stores WHERE id = $1 AND user_id = $2',
    [storeId, req.user.id]
  );

  if (!result.rows.length) {
    return res.status(403).json({ error: 'You do not own this store' });
  }

  req.store = result.rows[0];
  next();
}

module.exports = { requireAuth, optionalAuth, requireStoreOwner };
