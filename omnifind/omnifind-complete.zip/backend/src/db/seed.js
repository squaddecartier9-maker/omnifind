require('dotenv').config();
const { connectDB, query } = require('./client');

async function seed() {
  await connectDB();
  console.log('🌱 Seeding database...');

  // Plans
  await query(`
    INSERT INTO plans (name, price_monthly, max_stores, max_products, features) VALUES
    ('Starter', 0, 1, 100, '["Universal search listing","Public store link","0% transaction fees","Basic analytics"]'),
    ('Growth', 1900, 5, NULL, '["5 stores","Unlimited products","Advanced analytics","Referral system","Priority support"]'),
    ('Enterprise', 5900, NULL, NULL, '["Unlimited stores","API access","White-label option","Dedicated manager","Custom integrations"]')
    ON CONFLICT DO NOTHING
  `);

  // Demo user
  await query(`
    INSERT INTO users (clerk_id, email, name, role) VALUES
    ('demo_clerk_id', 'demo@omnifind.io', 'Demo Seller', 'seller')
    ON CONFLICT DO NOTHING
  `);

  const userRes = await query(`SELECT id FROM users WHERE email = 'demo@omnifind.io'`);
  const userId = userRes.rows[0].id;

  // Demo stores
  await query(`
    INSERT INTO stores (user_id, slug, name, description, category) VALUES
    ('${userId}', 'techshop-eu', 'TechShop EU', 'Premium tech accessories from Europe', 'tech'),
    ('${userId}', 'merino-world', 'MerinoWorld', 'Sustainable merino wool clothing', 'fashion'),
    ('${userId}', 'coffeecraft', 'CoffeeCraft', 'Specialty coffee roasted to order', 'food')
    ON CONFLICT DO NOTHING
  `);

  const storeRes = await query(`SELECT id FROM stores WHERE user_id = '${userId}'`);
  const storeId = storeRes.rows[0].id;

  // Demo products
  await query(`
    INSERT INTO products (store_id, name, slug, description, price, compare_at_price, stock, category, tags) VALUES
    ('${storeId}', 'Aluminium Laptop Stand Pro', 'aluminium-laptop-stand-pro', 'Adjustable aluminium stand compatible with all laptops. Folds flat for travel.', 8900, 12300, 47, 'tech', ARRAY['laptop','stand','aluminium','desk']),
    ('${storeId}', 'USB-C Hub 7-in-1', 'usb-c-hub-7in1', '7 ports: 4K HDMI, USB-A x3, SD card, PD 100W charging.', 4900, 6900, 23, 'tech', ARRAY['usb-c','hub','dongle']),
    ('${storeId}', 'Mechanical Keyboard TKL', 'mechanical-keyboard-tkl', 'Tenkeyless layout, Cherry MX Red switches, RGB backlight.', 12900, NULL, 12, 'tech', ARRAY['keyboard','mechanical','rgb'])
    ON CONFLICT DO NOTHING
  `);

  console.log('✅ Seed complete');
  process.exit(0);
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err);
  process.exit(1);
});
