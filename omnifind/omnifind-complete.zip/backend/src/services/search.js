const { MeiliSearch } = require('meilisearch');

let client;

function getSearch() {
  if (!client) {
    client = new MeiliSearch({
      host: process.env.MEILISEARCH_HOST || 'http://localhost:7700',
      apiKey: process.env.MEILISEARCH_KEY || 'masterKey',
    });
  }
  return client;
}

const INDEX = 'products';

async function setupIndex() {
  const search = getSearch();
  const index = search.index(INDEX);

  await search.createIndex(INDEX, { primaryKey: 'id' });

  await index.updateSettings({
    searchableAttributes: ['name', 'description', 'tags', 'category', 'store_name'],
    filterableAttributes: ['category', 'store_id', 'is_active', 'price', 'currency'],
    sortableAttributes: ['price', 'sales_count', 'created_at', 'views'],
    rankingRules: [
      'words', 'typo', 'proximity', 'attribute', 'sort', 'exactness',
      'sales_count:desc',
    ],
  });

  console.log('✅ Meilisearch index configured');
}

async function indexProduct(product) {
  const search = getSearch();
  await search.index(INDEX).addDocuments([{
    id: product.id,
    name: product.name,
    description: product.description,
    price: product.price,
    currency: product.currency,
    category: product.category,
    tags: product.tags || [],
    store_id: product.store_id,
    store_name: product.store_name,
    store_slug: product.store_slug,
    images: product.images,
    is_active: product.is_active,
    sales_count: product.sales_count,
    views: product.views,
    created_at: product.created_at,
  }]);
}

async function removeProduct(productId) {
  const search = getSearch();
  await search.index(INDEX).deleteDocument(productId);
}

async function searchProducts({ q = '', category, minPrice, maxPrice, sort = 'relevance', page = 1, limit = 20 }) {
  const search = getSearch();

  const filters = ['is_active = true'];
  if (category) filters.push(`category = "${category}"`);
  if (minPrice != null) filters.push(`price >= ${minPrice}`);
  if (maxPrice != null) filters.push(`price <= ${maxPrice}`);

  const sortMap = {
    relevance: [],
    price_asc: ['price:asc'],
    price_desc: ['price:desc'],
    newest: ['created_at:desc'],
    popular: ['sales_count:desc'],
  };

  const result = await search.index(INDEX).search(q, {
    filter: filters.join(' AND '),
    sort: sortMap[sort] || [],
    limit,
    offset: (page - 1) * limit,
    attributesToHighlight: ['name', 'description'],
    highlightPreTag: '<mark>',
    highlightPostTag: '</mark>',
  });

  return {
    hits: result.hits,
    total: result.estimatedTotalHits,
    page,
    limit,
    query: q,
  };
}

module.exports = { getSearch, setupIndex, indexProduct, removeProduct, searchProducts };
