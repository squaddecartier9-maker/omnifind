const { createClient } = require('redis');

let client;

async function connectRedis() {
  client = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
  client.on('error', (err) => console.error('Redis error:', err));
  await client.connect();
  console.log('✅ Redis connected');
}

function getRedis() {
  if (!client) throw new Error('Redis not initialized');
  return client;
}

async function cache(key, fn, ttlSeconds = 60) {
  const redis = getRedis();
  const cached = await redis.get(key);
  if (cached) return JSON.parse(cached);
  const result = await fn();
  await redis.setEx(key, ttlSeconds, JSON.stringify(result));
  return result;
}

async function invalidate(pattern) {
  const redis = getRedis();
  const keys = await redis.keys(pattern);
  if (keys.length) await redis.del(keys);
}

module.exports = { connectRedis, getRedis, cache, invalidate };
