const express = require('express');
const { query } = require('../db/client');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// GET /api/auth/me
router.get('/me', requireAuth, async (req, res) => {
  const stores = await query('SELECT * FROM stores WHERE user_id = $1', [req.user.id]);
  res.json({ user: req.user, stores: stores.rows });
});

// PATCH /api/auth/me
router.patch('/me', requireAuth, async (req, res, next) => {
  try {
    const { name, avatar_url } = req.body;
    const result = await query(
      'UPDATE users SET name = COALESCE($1, name), avatar_url = COALESCE($2, avatar_url), updated_at = NOW() WHERE id = $3 RETURNING *',
      [name, avatar_url, req.user.id]
    );
    res.json({ user: result.rows[0] });
  } catch (err) { next(err); }
});

module.exports = router;
