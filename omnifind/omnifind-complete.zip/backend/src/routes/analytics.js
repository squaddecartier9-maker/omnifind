const express = require('express');
const { query } = require('../db/client');
const { requireAuth } = require('../middleware/auth');
const { cache } = require('../services/redis');

const router = express.Router();

// GET /api/analytics/:storeId — full seller analytics
router.get('/:storeId', requireAuth, async (req, res, next) => {
  try {
    const { storeId } = req.params;
    const { period = '30d' } = req.query;

    // Verify ownership
    const check = await query('SELECT id FROM stores WHERE id = $1 AND user_id = $2', [storeId, req.user.id]);
    if (!check.rows.length) return res.status(403).json({ error: 'Forbidden' });

    const days = period === '7d' ? 7 : period === '90d' ? 90 : 30;
    const cacheKey = `analytics:${storeId}:${period}`;

    const data = await cache(cacheKey, async () => {
      // Revenue over time
      const revenueOverTime = await query(`
        SELECT
          DATE(created_at) as date,
          SUM(total) as revenue,
          COUNT(*) as orders
        FROM orders
        WHERE store_id = $1
          AND status IN ('confirmed','shipped','delivered')
          AND created_at >= NOW() - INTERVAL '${days} days'
        GROUP BY DATE(created_at)
        ORDER BY date ASC
      `, [storeId]);

      // Total stats
      const totals = await query(`
        SELECT
          SUM(total) as total_revenue,
          COUNT(*) as total_orders,
          AVG(total) as avg_order_value,
          COUNT(DISTINCT buyer_id) as unique_buyers
        FROM orders
        WHERE store_id = $1
          AND status IN ('confirmed','shipped','delivered')
          AND created_at >= NOW() - INTERVAL '${days} days'
      `, [storeId]);

      // Previous period for comparison
      const prevTotals = await query(`
        SELECT
          SUM(total) as total_revenue,
          COUNT(*) as total_orders
        FROM orders
        WHERE store_id = $1
          AND status IN ('confirmed','shipped','delivered')
          AND created_at >= NOW() - INTERVAL '${days * 2} days'
          AND created_at < NOW() - INTERVAL '${days} days'
      `, [storeId]);

      // Top products
      const topProducts = await query(`
        SELECT
          p.id, p.name, p.price, p.images,
          SUM(oi.quantity) as units_sold,
          SUM(oi.price * oi.quantity) as revenue
        FROM order_items oi
        JOIN products p ON p.id = oi.product_id
        JOIN orders o ON o.id = oi.order_id
        WHERE o.store_id = $1
          AND o.status IN ('confirmed','shipped','delivered')
          AND o.created_at >= NOW() - INTERVAL '${days} days'
        GROUP BY p.id, p.name, p.price, p.images
        ORDER BY revenue DESC
        LIMIT 5
      `, [storeId]);

      // Orders by status
      const ordersByStatus = await query(`
        SELECT status, COUNT(*) as count
        FROM orders
        WHERE store_id = $1
        GROUP BY status
      `, [storeId]);

      // Traffic (views)
      const views = await query(`
        SELECT SUM(views) as total_views
        FROM products
        WHERE store_id = $1
      `, [storeId]);

      const curr = totals.rows[0];
      const prev = prevTotals.rows[0];
      const revenueChange = prev.total_revenue > 0
        ? ((curr.total_revenue - prev.total_revenue) / prev.total_revenue * 100).toFixed(1)
        : 0;
      const ordersChange = prev.total_orders > 0
        ? ((curr.total_orders - prev.total_orders) / prev.total_orders * 100).toFixed(1)
        : 0;

      return {
        period,
        summary: {
          total_revenue: parseInt(curr.total_revenue || 0),
          total_orders: parseInt(curr.total_orders || 0),
          avg_order_value: parseInt(curr.avg_order_value || 0),
          unique_buyers: parseInt(curr.unique_buyers || 0),
          total_views: parseInt(views.rows[0].total_views || 0),
          revenue_change: parseFloat(revenueChange),
          orders_change: parseFloat(ordersChange),
        },
        revenue_over_time: revenueOverTime.rows,
        top_products: topProducts.rows,
        orders_by_status: ordersByStatus.rows,
      };
    }, 120);

    res.json(data);
  } catch (err) { next(err); }
});

module.exports = router;
