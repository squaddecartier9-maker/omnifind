const express = require('express');
const Stripe = require('stripe');
const { query } = require('../db/client');
const { requireAuth } = require('../middleware/auth');

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const router = express.Router();

// POST /api/stripe/checkout — create checkout session
router.post('/checkout', requireAuth, async (req, res, next) => {
  try {
    const { items, store_id, shipping_address } = req.body;
    // items: [{ product_id, quantity }]

    if (!items?.length) return res.status(400).json({ error: 'No items provided' });

    // Fetch all products
    const productIds = items.map(i => i.product_id);
    const productsResult = await query(
      `SELECT p.*, s.name as store_name FROM products p
       JOIN stores s ON s.id = p.store_id
       WHERE p.id = ANY($1) AND p.is_active = true`,
      [productIds]
    );

    const productMap = {};
    for (const p of productsResult.rows) productMap[p.id] = p;

    const lineItems = items.map(item => {
      const product = productMap[item.product_id];
      if (!product) throw new Error(`Product ${item.product_id} not found`);
      return {
        price_data: {
          currency: product.currency.toLowerCase(),
          product_data: {
            name: product.name,
            images: product.images?.[0] ? [product.images[0]] : [],
            metadata: { product_id: product.id },
          },
          unit_amount: product.price,
        },
        quantity: item.quantity,
      };
    });

    const subtotal = items.reduce((sum, item) => {
      const p = productMap[item.product_id];
      return sum + (p?.price || 0) * item.quantity;
    }, 0);

    // Create order record first
    const orderResult = await query(`
      INSERT INTO orders (buyer_id, store_id, status, subtotal, total, currency, shipping_address)
      VALUES ($1, $2, 'pending', $3, $3, 'EUR', $4) RETURNING id
    `, [req.user.id, store_id, subtotal, JSON.stringify(shipping_address || {})]);

    const orderId = orderResult.rows[0].id;

    // Create order items
    for (const item of items) {
      const product = productMap[item.product_id];
      await query(`
        INSERT INTO order_items (order_id, product_id, product_name, product_image, price, quantity)
        VALUES ($1, $2, $3, $4, $5, $6)
      `, [orderId, item.product_id, product.name, product.images?.[0] || null, product.price, item.quantity]);
    }

    // Create Stripe session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      success_url: `${process.env.FRONTEND_URL}/order/${orderId}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/cart`,
      metadata: { order_id: orderId, user_id: req.user.id },
      customer_email: req.user.email,
    });

    // Store session ID
    await query(
      'UPDATE orders SET stripe_checkout_session_id = $1 WHERE id = $2',
      [session.id, orderId]
    );

    res.json({ url: session.url, session_id: session.id, order_id: orderId });
  } catch (err) { next(err); }
});

// POST /api/stripe/webhook — Stripe events
router.post('/webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const orderId = session.metadata.order_id;

        await query(`
          UPDATE orders
          SET status = 'confirmed',
              stripe_payment_intent_id = $1,
              updated_at = NOW()
          WHERE id = $2
        `, [session.payment_intent, orderId]);

        // Update product sales counts
        const items = await query('SELECT product_id, quantity FROM order_items WHERE order_id = $1', [orderId]);
        for (const item of items.rows) {
          await query(
            'UPDATE products SET sales_count = sales_count + $1, stock = GREATEST(0, stock - $1) WHERE id = $2',
            [item.quantity, item.product_id]
          );
        }

        // Update store total_sales
        const order = await query('SELECT store_id, total FROM orders WHERE id = $1', [orderId]);
        if (order.rows.length) {
          await query(
            'UPDATE stores SET total_sales = total_sales + $1 WHERE id = $2',
            [order.rows[0].total, order.rows[0].store_id]
          );
        }

        console.log(`✅ Order ${orderId} confirmed`);
        break;
      }

      case 'checkout.session.expired': {
        const session = event.data.object;
        const orderId = session.metadata?.order_id;
        if (orderId) {
          await query("UPDATE orders SET status = 'cancelled' WHERE id = $1", [orderId]);
        }
        break;
      }

      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        // Handle plan changes
        const sub = event.data.object;
        const status = event.type === 'customer.subscription.deleted' ? 'cancelled' : sub.status;
        await query(
          "UPDATE subscriptions SET status = $1, updated_at = NOW() WHERE stripe_subscription_id = $2",
          [status, sub.id]
        );
        break;
      }
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Webhook handler error:', err);
    res.status(500).json({ error: 'Webhook handler failed' });
  }
});

// POST /api/stripe/subscription — upgrade plan
router.post('/subscription', requireAuth, async (req, res, next) => {
  try {
    const { price_id } = req.body;

    let customerId = req.user.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: req.user.email,
        name: req.user.name,
        metadata: { user_id: req.user.id },
      });
      customerId = customer.id;
      await query('UPDATE users SET stripe_customer_id = $1 WHERE id = $2', [customerId, req.user.id]);
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      mode: 'subscription',
      line_items: [{ price: price_id, quantity: 1 }],
      success_url: `${process.env.FRONTEND_URL}/dashboard?upgraded=true`,
      cancel_url: `${process.env.FRONTEND_URL}/pricing`,
      metadata: { user_id: req.user.id },
    });

    res.json({ url: session.url });
  } catch (err) { next(err); }
});

module.exports = router;
