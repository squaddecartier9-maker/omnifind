const express = require('express');
const { searchProducts } = require('../services/search');
const { cache } = require('../services/redis');

const router = express.Router();

// GET /api/search?q=laptop&category=tech&sort=price_asc&page=1
router.get('/', async (req, res, next) => {
  try {
    const { q = '', category, minPrice, maxPrice, sort, page = 1, limit = 20 } = req.query;

    const cacheKey = `search:${q}:${category}:${minPrice}:${maxPrice}:${sort}:${page}:${limit}`;

    const result = await cache(cacheKey, () =>
      searchProducts({
        q,
        category,
        minPrice: minPrice ? parseInt(minPrice) : undefined,
        maxPrice: maxPrice ? parseInt(maxPrice) : undefined,
        sort,
        page: parseInt(page),
        limit: parseInt(limit),
      }), 15
    );

    // Group results by store to show "also available at" comparisons
    const byProduct = {};
    for (const hit of result.hits) {
      const key = hit.name.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (!byProduct[key]) byProduct[key] = [];
      byProduct[key].push(hit);
    }

    res.json({
      ...result,
      comparisons: Object.values(byProduct).filter(g => g.length > 1),
    });
  } catch (err) { next(err); }
});

// GET /api/search/suggestions?q=lap
router.get('/suggestions', async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 2) return res.json({ suggestions: [] });

    const result = await searchProducts({ q, limit: 5 });
    const suggestions = result.hits.map(h => h.name).slice(0, 5);

    res.json({ suggestions });
  } catch (err) { next(err); }
});

// GET /api/search/categories — list all categories with count
router.get('/categories', async (req, res, next) => {
  try {
    const { query } = require('../db/client');
    const result = await query(`
      SELECT category, COUNT(*) as count
      FROM products
      WHERE is_active = true AND category IS NOT NULL
      GROUP BY category
      ORDER BY count DESC
    `);
    res.json({ categories: result.rows });
  } catch (err) { next(err); }
});

module.exports = router;
