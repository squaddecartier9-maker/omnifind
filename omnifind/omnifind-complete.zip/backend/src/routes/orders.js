const express = require('express');
const { query } = require('../db/client');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// GET /api/orders — buyer sees their orders
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const result = await query(`
      SELECT o.*, s.name as store_name, s.slug as store_slug,
        json_agg(json_build_object(
          'id', oi.id,
          'product_id', oi.product_id,
          'name', oi.product_name,
          'image', oi.product_image,
          'price', oi.price,
          'quantity', oi.quantity
        )) as items
      FROM orders o
      JOIN stores s ON s.id = o.store_id
      JOIN order_items oi ON oi.order_id = o.id
      WHERE o.buyer_id = $1
      GROUP BY o.id, s.name, s.slug
      ORDER BY o.created_at DESC
    `, [req.user.id]);
    res.json({ orders: result.rows });
  } catch (err) { next(err); }
});

// GET /api/orders/store/:storeId — seller sees store orders
router.get('/store/:storeId', requireAuth, async (req, res, next) => {
  try {
    const { storeId } = req.params;
    const { status, limit = 50, offset = 0 } = req.query;

    // Verify store ownership
    const check = await query('SELECT id FROM stores WHERE id = $1 AND user_id = $2', [storeId, req.user.id]);
    if (!check.rows.length) return res.status(403).json({ error: 'Forbidden' });

    let sql = `
      SELECT o.*, u.name as buyer_name, u.email as buyer_email,
        json_agg(json_build_object(
          'id', oi.id, 'name', oi.product_name,
          'price', oi.price, 'quantity', oi.quantity
        )) as items
      FROM orders o
      JOIN users u ON u.id = o.buyer_id
      JOIN order_items oi ON oi.order_id = o.id
      WHERE o.store_id = $1
    `;
    const params = [storeId];
    let i = 2;

    if (status) { sql += ` AND o.status = $${i++}`; params.push(status); }
    sql += ` GROUP BY o.id, u.name, u.email ORDER BY o.created_at DESC LIMIT $${i++} OFFSET $${i++}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await query(sql, params);
    res.json({ orders: result.rows });
  } catch (err) { next(err); }
});

// GET /api/orders/:id — single order
router.get('/:id', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await query(`
      SELECT o.*, s.name as store_name,
        json_agg(json_build_object(
          'id', oi.id, 'product_id', oi.product_id,
          'name', oi.product_name, 'image', oi.product_image,
          'price', oi.price, 'quantity', oi.quantity
        )) as items
      FROM orders o
      JOIN stores s ON s.id = o.store_id
      JOIN order_items oi ON oi.order_id = o.id
      WHERE o.id = $1 AND (o.buyer_id = $2 OR s.user_id = $2)
      GROUP BY o.id, s.name
    `, [id, req.user.id]);

    if (!result.rows.length) return res.status(404).json({ error: 'Order not found' });
    res.json({ order: result.rows[0] });
  } catch (err) { next(err); }
});

// PATCH /api/orders/:id/status — seller updates order status
router.patch('/:id/status', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const allowed = ['confirmed', 'shipped', 'delivered', 'cancelled'];
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status' });

    // Verify seller owns the store
    const check = await query(`
      SELECT o.id FROM orders o
      JOIN stores s ON s.id = o.store_id
      WHERE o.id = $1 AND s.user_id = $2
    `, [id, req.user.id]);

    if (!check.rows.length) return res.status(403).json({ error: 'Forbidden' });

    const result = await query(
      'UPDATE orders SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
      [status, id]
    );

    res.json({ order: result.rows[0] });
  } catch (err) { next(err); }
});

module.exports = router;
