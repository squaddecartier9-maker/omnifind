const express = require('express');
const { z } = require('zod');
const { query } = require('../db/client');
const { requireAuth, requireStoreOwner } = require('../middleware/auth');
const { indexProduct, removeProduct } = require('../services/search');
const { cache, invalidate } = require('../services/redis');

const router = express.Router();

const ProductSchema = z.object({
  store_id: z.string().uuid(),
  name: z.string().min(2).max(500),
  description: z.string().optional(),
  price: z.number().int().positive(),        // cents
  compare_at_price: z.number().int().positive().optional(),
  stock: z.number().int().min(0).default(0),
  category: z.string().optional(),
  tags: z.array(z.string()).optional(),
  attributes: z.record(z.any()).optional(),
  images: z.array(z.string()).optional(),
});

// GET /api/products — list products (optionally by store)
router.get('/', async (req, res, next) => {
  try {
    const { store_id, category, featured, limit = 20, offset = 0 } = req.query;
    const cacheKey = `products:${store_id}:${category}:${featured}:${limit}:${offset}`;

    const result = await cache(cacheKey, async () => {
      let sql = `
        SELECT p.*, s.name as store_name, s.slug as store_slug
        FROM products p
        JOIN stores s ON s.id = p.store_id
        WHERE p.is_active = true
      `;
      const params = [];
      let i = 1;

      if (store_id) { sql += ` AND p.store_id = $${i++}`; params.push(store_id); }
      if (category) { sql += ` AND p.category = $${i++}`; params.push(category); }
      if (featured === 'true') { sql += ` AND p.is_featured = true`; }

      sql += ` ORDER BY p.created_at DESC LIMIT $${i++} OFFSET $${i++}`;
      params.push(parseInt(limit), parseInt(offset));

      const res = await query(sql, params);
      return res.rows;
    }, 30);

    res.json({ products: result, limit: parseInt(limit), offset: parseInt(offset) });
  } catch (err) { next(err); }
});

// GET /api/products/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await cache(`product:${id}`, async () => {
      const r = await query(`
        SELECT p.*, s.name as store_name, s.slug as store_slug, s.logo_url as store_logo
        FROM products p
        JOIN stores s ON s.id = p.store_id
        WHERE p.id = $1 AND p.is_active = true
      `, [id]);
      return r.rows[0] || null;
    }, 60);

    if (!result) return res.status(404).json({ error: 'Product not found' });

    // Increment views async (don't await)
    query('UPDATE products SET views = views + 1 WHERE id = $1', [id]).catch(() => {});

    res.json({ product: result });
  } catch (err) { next(err); }
});

// POST /api/products — create product
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const data = ProductSchema.parse(req.body);

    // Verify store ownership
    const storeCheck = await query(
      'SELECT * FROM stores WHERE id = $1 AND user_id = $2',
      [data.store_id, req.user.id]
    );
    if (!storeCheck.rows.length) {
      return res.status(403).json({ error: 'You do not own this store' });
    }

    const slug = data.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');

    const result = await query(`
      INSERT INTO products (
        store_id, name, slug, description, price, compare_at_price,
        stock, category, tags, attributes, images
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      RETURNING *
    `, [
      data.store_id, data.name, slug, data.description,
      data.price, data.compare_at_price, data.stock,
      data.category, data.tags || [], data.attributes || {},
      JSON.stringify(data.images || [])
    ]);

    const product = result.rows[0];
    const store = storeCheck.rows[0];

    // Index in Meilisearch
    await indexProduct({ ...product, store_name: store.name, store_slug: store.slug });

    // Invalidate cache
    await invalidate(`products:${data.store_id}:*`);

    res.status(201).json({ product });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors });
    next(err);
  }
});

// PATCH /api/products/:id
router.patch('/:id', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params;

    // Verify ownership
    const check = await query(`
      SELECT p.*, s.name as store_name, s.slug as store_slug
      FROM products p JOIN stores s ON s.id = p.store_id
      WHERE p.id = $1 AND s.user_id = $2
    `, [id, req.user.id]);

    if (!check.rows.length) return res.status(403).json({ error: 'Forbidden' });

    const allowed = ['name', 'description', 'price', 'compare_at_price', 'stock', 'category', 'tags', 'images', 'attributes', 'is_active', 'is_featured'];
    const updates = {};
    for (const key of allowed) {
      if (req.body[key] !== undefined) updates[key] = req.body[key];
    }

    if (!Object.keys(updates).length) return res.status(400).json({ error: 'No valid fields to update' });

    const setClauses = Object.keys(updates).map((k, i) => `${k} = $${i + 2}`).join(', ');
    const values = Object.values(updates);

    const result = await query(
      `UPDATE products SET ${setClauses}, updated_at = NOW() WHERE id = $1 RETURNING *`,
      [id, ...values]
    );

    const product = result.rows[0];
    const storeData = check.rows[0];

    // Re-index
    await indexProduct({ ...product, store_name: storeData.store_name, store_slug: storeData.store_slug });
    await invalidate(`product:${id}`);
    await invalidate(`products:${product.store_id}:*`);

    res.json({ product });
  } catch (err) { next(err); }
});

// DELETE /api/products/:id
router.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params;
    const check = await query(`
      SELECT p.store_id FROM products p
      JOIN stores s ON s.id = p.store_id
      WHERE p.id = $1 AND s.user_id = $2
    `, [id, req.user.id]);

    if (!check.rows.length) return res.status(403).json({ error: 'Forbidden' });

    await query('UPDATE products SET is_active = false WHERE id = $1', [id]);
    await removeProduct(id);
    await invalidate(`product:${id}`);
    await invalidate(`products:${check.rows[0].store_id}:*`);

    res.json({ success: true });
  } catch (err) { next(err); }
});

module.exports = router;
