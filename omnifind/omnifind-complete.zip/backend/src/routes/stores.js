const express = require('express');
const { z } = require('zod');
const { query } = require('../db/client');
const { requireAuth } = require('../middleware/auth');
const { cache, invalidate } = require('../services/redis');

const router = express.Router();

const StoreSchema = z.object({
  name: z.string().min(2).max(255),
  description: z.string().optional(),
  category: z.string().optional(),
  currency: z.string().default('EUR'),
  country: z.string().default('EU'),
});

// GET /api/stores — browse all stores
router.get('/', async (req, res, next) => {
  try {
    const { category, limit = 20, offset = 0 } = req.query;
    const result = await cache(`stores:${category}:${limit}:${offset}`, async () => {
      let sql = `SELECT * FROM stores WHERE is_active = true`;
      const params = [];
      let i = 1;
      if (category) { sql += ` AND category = $${i++}`; params.push(category); }
      sql += ` ORDER BY total_sales DESC LIMIT $${i++} OFFSET $${i++}`;
      params.push(parseInt(limit), parseInt(offset));
      const r = await query(sql, params);
      return r.rows;
    }, 60);
    res.json({ stores: result });
  } catch (err) { next(err); }
});

// GET /api/stores/mine — seller's own stores
router.get('/mine', requireAuth, async (req, res, next) => {
  try {
    const result = await query(
      'SELECT * FROM stores WHERE user_id = $1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json({ stores: result.rows });
  } catch (err) { next(err); }
});

// GET /api/stores/:slug — public store page
router.get('/:slug', async (req, res, next) => {
  try {
    const { slug } = req.params;
    const result = await cache(`store:${slug}`, async () => {
      const r = await query('SELECT * FROM stores WHERE slug = $1 AND is_active = true', [slug]);
      return r.rows[0] || null;
    }, 120);
    if (!result) return res.status(404).json({ error: 'Store not found' });
    res.json({ store: result });
  } catch (err) { next(err); }
});

// POST /api/stores — create store
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const data = StoreSchema.parse(req.body);

    // Check plan limits
    const storeCount = await query('SELECT COUNT(*) FROM stores WHERE user_id = $1', [req.user.id]);
    const count = parseInt(storeCount.rows[0].count);

    // TODO: check subscription plan max_stores
    if (count >= 5) return res.status(403).json({ error: 'Store limit reached for your plan' });

    const slug = data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
      + '-' + Math.random().toString(36).slice(2, 6);

    const result = await query(`
      INSERT INTO stores (user_id, slug, name, description, category, currency, country)
      VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *
    `, [req.user.id, slug, data.name, data.description, data.category, data.currency, data.country]);

    await invalidate('stores:*');
    res.status(201).json({ store: result.rows[0] });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors });
    next(err);
  }
});

// PATCH /api/stores/:id
router.patch('/:id', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params;
    const check = await query('SELECT * FROM stores WHERE id = $1 AND user_id = $2', [id, req.user.id]);
    if (!check.rows.length) return res.status(403).json({ error: 'Forbidden' });

    const allowed = ['name', 'description', 'category', 'logo_url', 'banner_url', 'is_active'];
    const updates = {};
    for (const key of allowed) {
      if (req.body[key] !== undefined) updates[key] = req.body[key];
    }

    const setClauses = Object.keys(updates).map((k, i) => `${k} = $${i + 2}`).join(', ');
    const result = await query(
      `UPDATE stores SET ${setClauses}, updated_at = NOW() WHERE id = $1 RETURNING *`,
      [id, ...Object.values(updates)]
    );

    await invalidate(`store:${check.rows[0].slug}`);
    res.json({ store: result.rows[0] });
  } catch (err) { next(err); }
});

module.exports = router;
